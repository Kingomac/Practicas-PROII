package excepciones;

/**
 *
 * @author Mario
 */
public class CuentaIndiceExcepcion extends CuentaExcepcion {

    /**
     * Creates a new instance of <code>CuentaIndiceExcepcion</code> without
     * detail message.
     */
    public CuentaIndiceExcepcion() {
    }

    /**
     * Constructs an instance of <code>CuentaIndiceExcepcion</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public CuentaIndiceExcepcion(String msg) {
        super(msg);
    }
}
